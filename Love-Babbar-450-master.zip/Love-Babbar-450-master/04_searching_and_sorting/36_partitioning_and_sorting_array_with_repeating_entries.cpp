// link: https://www.baeldung.com/java-sorting-arrays-with-repeated-entries
