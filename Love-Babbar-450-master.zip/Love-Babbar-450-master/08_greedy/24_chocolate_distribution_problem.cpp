/*
	link: https://practice.geeksforgeeks.org/problems/chocolate-distribution-problem3825/1

	refer: array/30_chocolate_distribution....
*/

