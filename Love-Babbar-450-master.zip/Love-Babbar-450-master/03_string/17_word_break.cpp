/*
    link: https://practice.geeksforgeeks.org/problems/word-break1352/1

    ref: 14_DP/55_word_break_problem.cpp
*/