/*
    link: https://practice.geeksforgeeks.org/problems/next-permutation5226/1#

    ref: 1_array/15_next_permutation.cpp
*/